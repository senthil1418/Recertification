package com.pack.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pack.model.Product;
import com.pack.repoistory.ProductRepoistory;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/api")
public class ProductController {
	
	  @Autowired
	  ProductRepoistory repoistory;

	 @CrossOrigin(origins="http://localhost:4200")
     @GetMapping("/products/fetch")
     public List<Product> getAllProduct() {
       System.out.println("Get all product...");
    
       List<Product> products = new ArrayList<>();
       repoistory.findAll().forEach(products::add);
    
       return products;
     }
	
	 @CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/products/{id}")
	public Optional<Product> editId(@PathVariable("id") int id) {
		System.out.println("into by id");
		return repoistory.findById(id);
	}
     
	 @CrossOrigin(origins="http://localhost:4200")
	 @PutMapping(value = "/products/update")
     public Product updateProduct(@RequestBody Product product) {
       System.out.println("into update"+product.getId()+" "+product.getPrice());
		 Product product1 = repoistory.save(new Product(product.getId(),product.getTitle(), product.getPrice(),product.getIn_stock(),product.getCategory(),product.getDelivery()));
       return product1;
     }
}
