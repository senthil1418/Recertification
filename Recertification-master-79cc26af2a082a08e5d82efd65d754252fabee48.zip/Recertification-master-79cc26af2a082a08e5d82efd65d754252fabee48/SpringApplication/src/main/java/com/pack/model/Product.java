package com.pack.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {
@Id
@GeneratedValue
private Integer id;
private String title;
private Double price;
private String in_stock;
private String date;
private String category;
private String delivery;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public Double getPrice() {
	return price;
}
public void setPrice(Double price) {
	this.price = price;
}
public String getIn_stock() {
	return in_stock;
}
public void setIn_stock(String in_stock) {
	this.in_stock = in_stock;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getDelivery() {
	return delivery;
}
public void setDelivery(String delivery) {
	this.delivery = delivery;
}
public Product(Integer id, String title, Double price, String in_stock, String date, String category, String delivery) {
	super();
	this.id = id;
	this.title = title;
	this.price = price;
	this.in_stock = in_stock;
	this.date = date;
	this.category = category;
	this.delivery = delivery;
}
public Product() {
	super();
	// TODO Auto-generated constructor stub
}
public Product(Integer id, String title, Double price, String in_stock, String category, String delivery) {
	super();
	this.id = id;
	this.title = title;
	this.price = price;
	this.in_stock = in_stock;
	this.category = category;
	this.delivery = delivery;
}


}
