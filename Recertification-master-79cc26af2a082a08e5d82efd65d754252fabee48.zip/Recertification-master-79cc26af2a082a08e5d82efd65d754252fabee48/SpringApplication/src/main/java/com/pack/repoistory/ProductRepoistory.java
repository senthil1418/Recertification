package com.pack.repoistory;

import org.springframework.data.repository.CrudRepository;

import com.pack.model.Product;

public interface ProductRepoistory extends CrudRepository<Product,Integer> {
}
