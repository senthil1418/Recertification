import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Product } from '../product';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})
export class EditProductComponent implements OnInit {

  product: Product = new Product();
  constructor(private router: Router, private productService: ProductService) { }

  ngOnInit() {
     this.editProduct();
  }
  
  editProduct(){
     let id=localStorage.getItem("id");
     this.productService.getProductId(+id)
      .subscribe(data=>{
             this.product=data;
         })
   }

   onUpdate(){
console.log("into update");
this.productService.updateProduct(this.product)
      .subscribe(data => {
 console.log(data);

}, error => console.log(error));
    this.product = new Product();
}

}
