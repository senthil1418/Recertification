import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { ProductService } from '../product.service';
import { Product } from '../product';
 
import { ProductsListComponent } from '../products-list/products-list.component';
 
@Component({
  selector: 'product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {
 
  @Input() product: Product;
 
  constructor(private productService: ProductService, private listComponent: ProductsListComponent,private router: Router) { }
 
  ngOnInit() {
  }
 
editProduct(product: Product):void {
    console.log("into edit");
localStorage.setItem("id",product.id.toString());
 this.router.navigate(["edit"]);
  }

}




