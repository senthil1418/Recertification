import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
 import { Product } from './product';
@Injectable({
  providedIn: 'root'
})
export class ProductService {
 
  private baseUrl = 'http://localhost:8060/api/products';
 
  constructor(private http: HttpClient) { }
 
 

  getProductsList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`+`/fetch`);
  }
 
getProductId(id:number){
   return this.http.get(`${this.baseUrl}`+"/"+id);
}

updateProduct(product: Object): Observable<Object> {
    return this.http.put(`${this.baseUrl}` + `/update`, product);
  }

}