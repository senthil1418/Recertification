export class Product {
    id: number;
    title: string;
    price: number;
in_stock: string;
date: string;
category: string;
delivery: string;
    
}
